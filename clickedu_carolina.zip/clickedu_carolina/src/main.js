import { createApp } from 'vue';   // Usa createApp
import App from './App.vue';
import router from './router';
import './assets/styles.scss';      
// Importar Bootstrap y estilos
import 'bootstrap/dist/css/bootstrap.min.css'; 
import 'bootstrap';
// import BootstrapVue3 from 'bootstrap-vue-3';
import 'bootstrap-vue-3/dist/bootstrap-vue-3.css';
import 'bootstrap-icons/font/bootstrap-icons.css'; 

// import './assets/styles.css'; 
createApp(App)
  .use(router)                   // Usa el router
  .mount('#app');                 // Monta la aplicación
