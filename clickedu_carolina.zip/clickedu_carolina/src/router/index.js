import { createRouter, createWebHashHistory } from 'vue-router';


const routes =  [
    {
        path: '/',
        name: 'LoginPage',
        component: () => import('@/components/LoginPage.vue'),
        meta: {
            breadcrumb: [
                {
                    text: 'Login',
                    active: true,
                },
            ],
        },
    },
    {
        path: '/home',
        name: 'home',
        component: () => import('@/components/HelloWorld.vue'),
        meta: {
            breadcrumb: [
                {
                    text: 'Home',
                    active: true,
                },
            ],
        },
    },
]

const router = createRouter({
    history: createWebHashHistory(),
    routes
  });
  
  export default router;
