<template>
  <b-row>
    <b-col></b-col>
  </b-row>
    <div>
      <h2>Login</h2>
      <form>
        <input type="text" placeholder="Username" />
        <input type="password" placeholder="Password" />
        <button type="submit">Login</button>
      </form>
    </div>
  </template>
  
  <script>
  export default {
    name: 'LoginPage',
  };
  </script>
  
  <style scoped>
  /* Aquí puedes agregar los estilos de tu formulario de login */
  </style>
  